import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.ems.controller.DBEmployee;
import com.ems.modal.Employee;


public class Application {

	public static void main(String[] args) {
		
	//1.2 Print all the Values from Database	
	DBEmployee dbemployee= new DBEmployee();
	System.out.println("****------Employee Details-------****");
	List<Employee> emp= dbemployee.findAll();
	for(Employee employee:emp) {
		System.out.println(employee);
	}
	
	
	
	//1.3 Filter data using streams in java8
	System.out.println("\n****-----Filter details----****");
	List<Employee> empdep= emp.stream().filter(d-> d.getDepartment().equalsIgnoreCase("IT")).collect(Collectors.toList());
	for(Employee dep:empdep) {
		System.out.println(dep);
	}
	
	//1.4 Copy all filtered items into Map
	System.out.println("\n****----- Map------****");
	Map<String, String> depmap= new HashMap<String, String>();
	for(Employee mapEmpDep:empdep) {
		depmap.put(mapEmpDep.getDepartment(),mapEmpDep.getFirstName());
		
	}
	System.out.println(depmap);
	}
}
