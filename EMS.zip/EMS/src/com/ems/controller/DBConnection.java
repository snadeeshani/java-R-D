//package com.ems.controller;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//
//import com.mysql.jdbc.ResultSet;
//import com.mysql.jdbc.Statement;
//
//public class DBConnection {
//
//	String serverIp = "localhost";
//    String databasename = "dbems";
//    String dbUserName = "root";
//    String password = "";
//    public Connection conn;
//    DriverManager drManager;
//    Statement statment;
//    ResultSet resultset;
//
//    public void creatConnection() {
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            conn = (Connection) drManager.getConnection("jdbc:mysql://" + serverIp + "/" + databasename + "", dbUserName, "");
//            statment = (Statement) conn.createStatement();
//
//        } catch (Exception e) {
//
//            e.printStackTrace();
//        }
//
//    }
//
//    public void exeCuteUpdate(String url)  {
//        try {
//            creatConnection();
//
//            statment.executeUpdate(url);
//
//        } catch (Exception ex) {
//           ex.printStackTrace();
//        }
//
//
//
//
//    }
//
//    public ResultSet exeCuteQuery(String url)  {
//        try {
//            creatConnection();
//
//            resultset= (ResultSet) statment.executeQuery(url);
//
//            
//        } catch (Exception ex) {
//          ex.printStackTrace();
//        }return resultset;
//        
//    }
//    public boolean isNumeric(String n)
//        {
//            try
//            {
//                Integer.parseInt(n);
//                return true;
//            }
//            catch(Exception e)
//            {
//                return false;
//            }
//        }
//
//}
