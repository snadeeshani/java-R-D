package com.ems.controller;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ems.modal.Employee;
import java.sql.*;

public class DBEmployee {

	
	public List<Employee> findAll(){
		try {
			List<Employee> employeeList= new ArrayList<Employee>();
			PreparedStatement preparedStatement= ConnectDB.getConnection().prepareStatement("SELECT * FROM employee");
			ResultSet rs= preparedStatement.executeQuery();
			while(rs.next()) {
				Employee employee= new Employee();
				employee.setId(rs.getInt("id"));
				employee.setFirstName(rs.getString("first_name"));
				employee.setLastName(rs.getString("last_name"));
				employee.setAddress(rs.getString("address"));
				employee.setEmail(rs.getString("email"));
				employee.setContactNo(rs.getInt("contact_no"));
				employee.setJoinDate(rs.getDate("join_date"));
				employee.setSalary(rs.getDouble("salary"));
				employee.setDepartment(rs.getString("department"));
				employeeList.add(employee);
			}
			return employeeList;
		} catch (Exception e) {
			return null;
		}
	}

	}
